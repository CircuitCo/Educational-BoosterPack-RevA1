Date : 11/27/2012 



README for Gerber Educational BoosterPack Rev A1.zip

Files contained in the zip file:

README		      					This file
Educational BoosterPack Rev A1.cmp   			Layer top (Component)
Educational BoosterPack Rev A1.sol     			Layer bottom (Solder)
Educational BoosterPack Rev A1.stc   			Soldermask Layer top (Component)
Educational BoosterPack Rev A1.sts    			Soldermask Layer bottom (Solder)
Educational BoosterPack Rev A1.tsp    			Solder Paste Layer top 
Educational BoosterPack Rev A1.slk 			Silk Screen Layer top
Educational BoosterPack Rev A1.bsk			Silk Screen Layer bottom 
Educational BoosterPack Rev A1.bol    			Fabrication and board outline Drawing (for Ref. ONLY)
Educational BoosterPack Rev A1.drd			NC Drill file
Educational BoosterPack Rev A1.dri			Drill tool file
Educational BoosterPack Rev A1.drl			Drill tool file
Educational BoosterPack Rev A1.gpi			Extra Gerber file 
Educational BoosterPack Rev A1.brd			File layout Eagle ver 6.1
Educational BoosterPack Rev A1.sch			File schematic Eagle ver6.1
Educational BoosterPack Rev A1_CCo-Boost.lbr		File library

Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.
